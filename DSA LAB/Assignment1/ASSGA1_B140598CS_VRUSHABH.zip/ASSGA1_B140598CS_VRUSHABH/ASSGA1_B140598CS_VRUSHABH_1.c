#include<stdio.h>
int main(){
	int a[100][100],n,i,j,k,temp;

	scanf("%d",&n);

	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
			}

	printf("\n");
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			temp=a[i][j];
			a[i][j]=a[j][i];
			a[j][i]=temp;
				}
			}
	for(i = 0; i < n / 2; i++){
        	for(j = 0; j < n; j++){
            		   temp=a[j][i];
            	            a[j][i] =a[j][n - i - 1];
		            a[j][n - i - 1] =temp;
        		}
    		}

	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			printf("%d\t",a[i][j]);
		printf("\n");
			}

	return 0;

}
