#include<stdio.h>

void printClockwise(int a[100][100], int p,int q){

    int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}	
		return ;
	}else if(q ==1){
		for(i = 0; i < p; ++i){
			printf("%d\t",a[i][0]);
		}
	  return;
	}
    while(output <  (p * q)){
        for(i = m; i < q - m ; ++i){
            printf("%d\t",a[m][i]);
		output++;
        }
        for(i = m + 1; i < (p - m); ++i){
            printf("%d\t",a[i][q - m - 1]);
		output++;

        }

        for(j = (q - m - 2); j >= m ; --j){
            printf("%d\t", a[p - m - 1][j]);
		output++;

        }
        for(i = p - m-2; i > m; --i){
            printf("%d\t",a[i][m]);
		output++;

        }
        m++;

    }

	return ;

}



void printAntiClockwise(int a[100][100],int p,int q){

   int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}
		return;
	}else if(q == 1){
		for(i =0 ; i < p ; ++i){
			printf("%d\t",a[i][0]);
		}
		return ;
	}
	
    while(output <  (p * q)){
		
        for(i = m; i < p - m; ++i){
            printf("%d\t",a[i][m]);
		output++;

        }

        for(i = m + 1; i < (q - m); ++i){
            printf("%d\t",a[p - m - 1][i]);
		output++;

        }

        for(j = (p - m - 2); j >= m ; --j){
            printf("%d\t", a[j][q - m - 1]);
		output++;

        }

        for(i = q - m - 2; i > m; --i){
            printf("%d\t",a[m][i]);
		output++;

        }
        m++;

    }

}



int main(){

    int i = 0, j = 0,p,q,choice = 0;

    int m[100][100];

    

    scanf("%d %d",&p,&q);

    

    for(i = 0;i < p; ++i){

        for(j = 0;j < q; ++j){

            scanf("%d",&m[i][j]);

        }

    }



    do{

        printf("\nMenu:\n1. Clockwise spiral-order traversal\n2. Anti-clockwise spiral-order traversal\n3. Exit\n");

        printf("\tEnter Your Choice: \n\t");

        scanf("%d",&choice);

        switch (choice) {

            case 1:

                printf("\tOutput: \n\t");

                printClockwise(m,p,q);

                break;

            case 2:

                printf("\tOutput: \n\t");

                printAntiClockwise(m,p,q);

                break;

            case 3:

                choice = 3;

                break;

            default:

                printf("\tInvalid Choice!!\n");

                break;

        }

    }while(choice!=3);

    printf("\n");

    return 0;

}

#include<stdio.h>

void printClockwise(int a[100][100], int p,int q){

    int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}	
		return ;
	}else if(q ==1){
		for(i = 0; i < p; ++i){
			printf("%d\t",a[i][0]);
		}
	  return;
	}
    while(output <  (p * q)){
        for(i = m; i < q - m ; ++i){
            printf("%d\t",a[m][i]);
		output++;
        }
        for(i = m + 1; i < (p - m); ++i){
            printf("%d\t",a[i][q - m - 1]);
		output++;

        }

        for(j = (q - m - 2); j >= m ; --j){
            printf("%d\t", a[p - m - 1][j]);
		output++;

        }
        for(i = p - m-2; i > m; --i){
            printf("%d\t",a[i][m]);
		output++;

        }
        m++;

    }

	return ;

}



void printAntiClockwise(int a[100][100],int p,int q){

   int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}
		return;
	}else if(q == 1){
		for(i =0 ; i < p ; ++i){
			printf("%d\t",a[i][0]);
		}
		return ;
	}
	
    while(output <  (p * q)){
		
        for(i = m; i < p - m; ++i){
            printf("%d\t",a[i][m]);
		output++;

        }

        for(i = m + 1; i < (q - m); ++i){
            printf("%d\t",a[p - m - 1][i]);
		output++;

        }

        for(j = (p - m - 2); j >= m ; --j){
            printf("%d\t", a[j][q - m - 1]);
		output++;

        }

        for(i = q - m - 2; i > m; --i){
            printf("%d\t",a[m][i]);
		output++;

        }
        m++;

    }

}



int main(){

    int i = 0, j = 0,p,q,choice = 0;

    int m[100][100];

    

    scanf("%d %d",&p,&q);

    

    for(i = 0;i < p; ++i){

        for(j = 0;j < q; ++j){

            scanf("%d",&m[i][j]);

        }

    }



    do{

        printf("\nMenu:\n1. Clockwise spiral-order traversal\n2. Anti-clockwise spiral-order traversal\n3. Exit\n");

        printf("\tEnter Your Choice: \n\t");

        scanf("%d",&choice);

        switch (choice) {

            case 1:

                printf("\tOutput: \n\t");

                printClockwise(m,p,q);

                break;

            case 2:

                printf("\tOutput: \n\t");

                printAntiClockwise(m,p,q);

                break;

            case 3:

                choice = 3;

                break;

            default:

                printf("\tInvalid Choice!!\n");

                break;

        }

    }while(choice!=3);

    printf("\n");

    return 0;

}

#include<stdio.h>

void printClockwise(int a[100][100], int p,int q){

    int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}	
		return ;
	}else if(q ==1){
		for(i = 0; i < p; ++i){
			printf("%d\t",a[i][0]);
		}
	  return;
	}
    while(output <  (p * q)){
        for(i = m; i < q - m ; ++i){
            printf("%d\t",a[m][i]);
		output++;
        }
        for(i = m + 1; i < (p - m); ++i){
            printf("%d\t",a[i][q - m - 1]);
		output++;

        }

        for(j = (q - m - 2); j >= m ; --j){
            printf("%d\t", a[p - m - 1][j]);
		output++;

        }
        for(i = p - m-2; i > m; --i){
            printf("%d\t",a[i][m]);
		output++;

        }
        m++;

    }

	return ;

}



void printAntiClockwise(int a[100][100],int p,int q){

   int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}
		return;
	}else if(q == 1){
		for(i =0 ; i < p ; ++i){
			printf("%d\t",a[i][0]);
		}
		return ;
	}
	
    while(output <  (p * q)){
		
        for(i = m; i < p - m; ++i){
            printf("%d\t",a[i][m]);
		output++;

        }

        for(i = m + 1; i < (q - m); ++i){
            printf("%d\t",a[p - m - 1][i]);
		output++;

        }

        for(j = (p - m - 2); j >= m ; --j){
            printf("%d\t", a[j][q - m - 1]);
		output++;

        }

        for(i = q - m - 2; i > m; --i){
            printf("%d\t",a[m][i]);
		output++;

        }
        m++;

    }

}



int main(){

    int i = 0, j = 0,p,q,choice = 0;

    int m[100][100];

    

    scanf("%d %d",&p,&q);

    

    for(i = 0;i < p; ++i){

        for(j = 0;j < q; ++j){

            scanf("%d",&m[i][j]);

        }

    }



    do{

        printf("\nMenu:\n1. Clockwise spiral-order traversal\n2. Anti-clockwise spiral-order traversal\n3. Exit\n");

        printf("\tEnter Your Choice: \n\t");

        scanf("%d",&choice);

        switch (choice) {

            case 1:

                printf("\tOutput: \n\t");

                printClockwise(m,p,q);

                break;

            case 2:

                printf("\tOutput: \n\t");

                printAntiClockwise(m,p,q);

                break;

            case 3:

                choice = 3;

                break;

            default:

                printf("\tInvalid Choice!!\n");

                break;

        }

    }while(choice!=3);

    printf("\n");

    return 0;

}

#include<stdio.h>

void printClockwise(int a[100][100], int p,int q){

    int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}	
		return ;
	}else if(q ==1){
		for(i = 0; i < p; ++i){
			printf("%d\t",a[i][0]);
		}
	  return;
	}
    while(output <  (p * q)){
        for(i = m; i < q - m ; ++i){
            printf("%d\t",a[m][i]);
		output++;
        }
        for(i = m + 1; i < (p - m); ++i){
            printf("%d\t",a[i][q - m - 1]);
		output++;

        }

        for(j = (q - m - 2); j >= m ; --j){
            printf("%d\t", a[p - m - 1][j]);
		output++;

        }
        for(i = p - m-2; i > m; --i){
            printf("%d\t",a[i][m]);
		output++;

        }
        m++;

    }

	return ;

}



void printAntiClockwise(int a[100][100],int p,int q){

   int output = 1, i, j, m = 0;

    printf("\n\t");
	if(p == 1){
		for(i = 0; i < q; ++i){
			printf("%d\t",a[0][i]);
		}
		return;
	}else if(q == 1){
		for(i =0 ; i < p ; ++i){
			printf("%d\t",a[i][0]);
		}
		return ;
	}
	
    while(output <  (p * q)){
		
        for(i = m; i < p - m; ++i){
            printf("%d\t",a[i][m]);
		output++;

        }

        for(i = m + 1; i < (q - m); ++i){
            printf("%d\t",a[p - m - 1][i]);
		output++;

        }

        for(j = (p - m - 2); j >= m ; --j){
            printf("%d\t", a[j][q - m - 1]);
		output++;

        }

        for(i = q - m - 2; i > m; --i){
            printf("%d\t",a[m][i]);
		output++;

        }
        m++;

    }

}



int main(){

    int i = 0, j = 0,p,q,choice = 0;

    int m[100][100];

    

    scanf("%d %d",&p,&q);

    

    for(i = 0;i < p; ++i){

        for(j = 0;j < q; ++j){

            scanf("%d",&m[i][j]);

        }

    }



    do{

        printf("\nMenu:\n1. Clockwise spiral-order traversal\n2. Anti-clockwise spiral-order traversal\n3. Exit\n");

        printf("\tEnter Your Choice: \n\t");

        scanf("%d",&choice);

        switch (choice) {

            case 1:

                printf("\tOutput: \n\t");

                printClockwise(m,p,q);

                break;

            case 2:

                printf("\tOutput: \n\t");

                printAntiClockwise(m,p,q);

                break;

            case 3:

                choice = 3;

                break;

            default:

                printf("\tInvalid Choice!!\n");

                break;

        }

    }while(choice!=3);

    printf("\n");

    return 0;

}

