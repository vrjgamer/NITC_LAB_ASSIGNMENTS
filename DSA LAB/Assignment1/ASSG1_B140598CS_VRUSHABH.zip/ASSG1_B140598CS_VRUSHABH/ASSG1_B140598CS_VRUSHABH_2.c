#include<stdio.h>

int count(int n ,int sum){	
	if(n < 0){
		return sum;
	}
	if(n%2 == 1){
		sum++;
	}
	return count(n/2,sum);
}

int main(){
	int decimal,n , count_one =0;
	printf("Enter a positive decimal number: ");
	scanf("%d",&decimal);
	if(n >= 2147483648 || n < 0){
		printf("Please Enter a Valid Input!!\n");
		return -1;
	}
	n = decimal;
	count_one = count(n,0);
	printf("The binary representation of %d contains %d 1's.\n",decimal , count_one);
	return 0;
}