If you are using 32-bit operating system, simply replace rax, rbx, rcx, rdx etc with eax, ebx, ecx, edx etc
to stop the complaining assembler.
